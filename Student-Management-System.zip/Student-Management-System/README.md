# Student Management System

## Project Description
A menu-driven Python application to manage student records. It stores student information in a local JSON file, so records remain available after the program closes.

## Features
- Add a student record
- View all student records
- Search by student ID
- Update student information
- Delete a record with confirmation
- Validate input and handle common errors
- Save and load records using JSON

## Technologies Used
- Python 3
- `json` and `pathlib` standard-library modules
- Git and GitHub

## Python Concepts Used
Variables and data types, input/output, operators, conditionals, loops, functions, lists, dictionaries, file handling, exception handling, classes and objects, constructors, inheritance, encapsulation, and a polymorphism-friendly `display()` method.

## Project Structure
```text
Student-Management-System/
├── main.py
├── students.json
├── requirements.txt
├── README.md
├── screenshots/
└── Project_Report.pdf
```

## Installation / Setup
1. Install Python 3 from https://www.python.org/downloads/
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. (Optional) create a virtual environment:
   - Windows: `py -m venv .venv`
   - Activate: `.venv\\Scripts\\activate`
5. No third-party packages are required.

## How to Run
From the project folder, run:

```bash
py main.py
```

If `py` is not available, try:

```bash
python main.py
```

Follow the menu instructions. Records are stored in `students.json`.

## GitHub Upload (Windows)
```bash
git init
git status
git add .
git commit -m "Initial Student Management System project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/Student-Management-System.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username. Create the empty repository on GitHub first. If Git asks for identity, configure it:
```bash
git config --global user.name "Your Name"
git config --global user.email "your-email@example.com"
```

## Future Improvements
- Add a graphical interface using Tkinter
- Add login and role-based access
- Export reports to CSV or PDF
- Add sorting and course-wise filtering
- Use SQLite for larger datasets

## Author
Student Name: [Enter your name]
Internship Domain: Python Development
Week: 6 of 6
