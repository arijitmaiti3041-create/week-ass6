import json
from pathlib import Path


DATA_FILE = Path(__file__).with_name("students.json")


class Person:
    """Base class for people in the system."""

    def __init__(self, name, age):
        self._name = name.strip()
        self._age = int(age)

    @property
    def name(self):
        return self._name

    @property
    def age(self):
        return self._age


class Student(Person):
    """Represents one student record."""

    def __init__(self, student_id, name, age, course, city):
        super().__init__(name, age)
        self.__student_id = student_id.strip()
        self._course = course.strip()
        self._city = city.strip()

    @property
    def student_id(self):
        return self.__student_id

    def to_dict(self):
        return {
            "student_id": self.student_id,
            "name": self.name,
            "age": self.age,
            "course": self._course,
            "city": self._city,
        }

    def display(self):
        # Polymorphism-friendly method: subclasses may override this.
        print(
            f"ID: {self.student_id} | Name: {self.name} | Age: {self.age} | "
            f"Course: {self._course} | City: {self._city}"
        )


class StudentManagementSystem:
    """Menu-driven student record manager with JSON file storage."""

    def __init__(self, data_file=DATA_FILE):
        self.data_file = Path(data_file)
        self.students = []
        self.load_students()

    def load_students(self):
        try:
            if self.data_file.exists():
                with self.data_file.open("r", encoding="utf-8") as file:
                    records = json.load(file)
                if not isinstance(records, list):
                    raise ValueError("Student data must be a list.")
                self.students = [
                    Student(
                        item["student_id"], item["name"], item["age"],
                        item["course"], item["city"]
                    )
                    for item in records
                ]
            else:
                self.students = []
        except (json.JSONDecodeError, OSError, KeyError, TypeError, ValueError) as error:
            print(f"Warning: Could not load student data: {error}")
            self.students = []

    def save_students(self):
        try:
            with self.data_file.open("w", encoding="utf-8") as file:
                json.dump(
                    [student.to_dict() for student in self.students],
                    file,
                    indent=4,
                    ensure_ascii=False,
                )
        except OSError as error:
            print(f"Error saving student data: {error}")

    def find_student(self, student_id):
        for student in self.students:
            if student.student_id.lower() == student_id.strip().lower():
                return student
        return None

    def add_student(self):
        print("\n--- Add Student ---")
        student_id = input("Enter student ID: ").strip()
        if not student_id:
            print("Student ID cannot be empty.")
            return
        if self.find_student(student_id):
            print("A student with this ID already exists.")
            return

        name = input("Enter name: ").strip()
        if not name:
            print("Name cannot be empty.")
            return

        try:
            age = int(input("Enter age: "))
            if age < 1 or age > 120:
                print("Please enter an age between 1 and 120.")
                return
        except ValueError:
            print("Invalid age. Please enter a whole number.")
            return

        course = input("Enter course: ").strip()
        city = input("Enter city: ").strip()
        if not course or not city:
            print("Course and city cannot be empty.")
            return

        self.students.append(Student(student_id, name, age, course, city))
        self.save_students()
        print("Student added successfully.")

    def view_students(self):
        print("\n--- Student List ---")
        if not self.students:
            print("No student records found.")
            return
        for student in self.students:
            student.display()

    def search_student(self):
        student_id = input("Enter student ID to search: ").strip()
        student = self.find_student(student_id)
        if student:
            print("Student found:")
            student.display()
        else:
            print("Student not found.")

    def update_student(self):
        student_id = input("Enter student ID to update: ").strip()
        student = self.find_student(student_id)
        if not student:
            print("Student not found.")
            return

        print("Leave a field blank to keep its current value.")
        name = input(f"Name [{student.name}]: ").strip()
        age_text = input(f"Age [{student.age}]: ").strip()
        course = input(f"Course [{student._course}]: ").strip()
        city = input(f"City [{student._city}]: ").strip()

        if name:
            student._name = name
        if age_text:
            try:
                age = int(age_text)
                if age < 1 or age > 120:
                    print("Age must be between 1 and 120; age unchanged.")
                else:
                    student._age = age
            except ValueError:
                print("Invalid age; age unchanged.")
        if course:
            student._course = course
        if city:
            student._city = city

        self.save_students()
        print("Student record updated.")

    def delete_student(self):
        student_id = input("Enter student ID to delete: ").strip()
        student = self.find_student(student_id)
        if not student:
            print("Student not found.")
            return
        confirm = input(f"Delete {student.name} ({student.student_id})? (y/n): ").strip().lower()
        if confirm == "y":
            self.students.remove(student)
            self.save_students()
            print("Student deleted.")
        else:
            print("Delete cancelled.")

    @staticmethod
    def show_menu():
        print("\n========== STUDENT MANAGEMENT SYSTEM ==========")
        print("1. Add student")
        print("2. View all students")
        print("3. Search student")
        print("4. Update student")
        print("5. Delete student")
        print("6. Exit")
        print("================================================")

    def run(self):
        while True:
            self.show_menu()
            choice = input("Choose an option (1-6): ").strip()
            if choice == "1":
                self.add_student()
            elif choice == "2":
                self.view_students()
            elif choice == "3":
                self.search_student()
            elif choice == "4":
                self.update_student()
            elif choice == "5":
                self.delete_student()
            elif choice == "6":
                print("Thank you for using Student Management System!")
                break
            else:
                print("Invalid choice. Please select a number from 1 to 6.")


if __name__ == "__main__":
    StudentManagementSystem().run()
